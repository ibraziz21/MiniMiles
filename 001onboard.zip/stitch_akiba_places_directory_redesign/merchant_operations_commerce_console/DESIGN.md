---
name: Merchant Operations & Commerce Console
colors:
  surface: '#f9f9f9'
  surface-dim: '#dadada'
  surface-bright: '#f9f9f9'
  surface-container-lowest: '#ffffff'
  surface-container-low: '#f3f3f3'
  surface-container: '#eeeeee'
  surface-container-high: '#e8e8e8'
  surface-container-highest: '#e2e2e2'
  on-surface: '#1a1c1c'
  on-surface-variant: '#3e494b'
  inverse-surface: '#2f3131'
  inverse-on-surface: '#f0f1f1'
  outline: '#6e797b'
  outline-variant: '#bdc8cb'
  surface-tint: '#006875'
  primary: '#006673'
  on-primary: '#ffffff'
  primary-container: '#048090'
  on-primary-container: '#f8feff'
  inverse-primary: '#77d4e5'
  secondary: '#006876'
  on-secondary: '#ffffff'
  secondary-container: '#99ecfd'
  on-secondary-container: '#006d7b'
  tertiary: '#525e60'
  on-tertiary: '#ffffff'
  tertiary-container: '#6a7779'
  on-tertiary-container: '#f6feff'
  error: '#ba1a1a'
  on-error: '#ffffff'
  error-container: '#ffdad6'
  on-error-container: '#93000a'
  primary-fixed: '#9eefff'
  primary-fixed-dim: '#77d4e5'
  on-primary-fixed: '#001f24'
  on-primary-fixed-variant: '#004e59'
  secondary-fixed: '#9fefff'
  secondary-fixed-dim: '#80d3e3'
  on-secondary-fixed: '#001f25'
  on-secondary-fixed-variant: '#004e59'
  tertiary-fixed: '#d8e5e7'
  tertiary-fixed-dim: '#bcc9cb'
  on-tertiary-fixed: '#121d1f'
  on-tertiary-fixed-variant: '#3d494b'
  background: '#f9f9f9'
  on-background: '#1a1c1c'
  surface-variant: '#e2e2e2'
typography:
  headline-lg:
    fontFamily: DM Sans
    fontSize: 32px
    fontWeight: '700'
    lineHeight: 40px
    letterSpacing: -0.02em
  headline-lg-mobile:
    fontFamily: DM Sans
    fontSize: 26px
    fontWeight: '700'
    lineHeight: 32px
    letterSpacing: -0.015em
  headline-md:
    fontFamily: DM Sans
    fontSize: 24px
    fontWeight: '600'
    lineHeight: 30px
    letterSpacing: -0.01em
  headline-sm:
    fontFamily: DM Sans
    fontSize: 20px
    fontWeight: '600'
    lineHeight: 26px
    letterSpacing: -0.005em
  title-md:
    fontFamily: DM Sans
    fontSize: 16px
    fontWeight: '600'
    lineHeight: 22px
    letterSpacing: 0em
  body-lg:
    fontFamily: DM Sans
    fontSize: 16px
    fontWeight: '400'
    lineHeight: 24px
    letterSpacing: 0em
  body-md:
    fontFamily: DM Sans
    fontSize: 14px
    fontWeight: '400'
    lineHeight: 20px
    letterSpacing: 0em
  body-sm:
    fontFamily: DM Sans
    fontSize: 12px
    fontWeight: '400'
    lineHeight: 16px
    letterSpacing: 0.01em
  label-lg:
    fontFamily: DM Sans
    fontSize: 14px
    fontWeight: '600'
    lineHeight: 18px
    letterSpacing: 0.01em
  label-md:
    fontFamily: DM Sans
    fontSize: 12px
    fontWeight: '500'
    lineHeight: 16px
    letterSpacing: 0.02em
  label-sm:
    fontFamily: DM Sans
    fontSize: 11px
    fontWeight: '600'
    lineHeight: 14px
    letterSpacing: 0.04em
  data-metric:
    fontFamily: DM Sans
    fontSize: 28px
    fontWeight: '700'
    lineHeight: 34px
    letterSpacing: -0.02em
rounded:
  sm: 0.25rem
  DEFAULT: 0.5rem
  md: 0.75rem
  lg: 1rem
  xl: 1.5rem
  full: 9999px
spacing:
  gutter: 1rem
  gutter-desktop: 1.5rem
  margin: 1rem
  margin-tablet: 1.5rem
  margin-desktop: 2rem
  space-xs: 0.25rem
  space-sm: 0.5rem
  space-md: 0.75rem
  space-lg: 1rem
  space-xl: 1.5rem
  space-2xl: 2rem
---

## Brand & Style

The design system establishes a high-trust, friction-free environment tailored for commercial operators, high-volume merchants, and financial administrators. The brand personality is utilitarian, dependable, precise, and calm under operational pressure. The interface reduces visual fatigue during sustained daily usage while maintaining crisp legibility in variable ambient light conditions (e.g., countertop points of sale, desktop back-office dashboards, or handheld stock checks).

The aesthetic approach draws from modern functional minimalism paired with subtle tonal layering:
- **No Cover Imagery or Decorative Distractions:** Zero decorative banners, background illustrations, or superfluous marketing artwork. Every pixel serves informational or actionable utility.
- **Compact & High-Density Hierarchy:** Headers and metadata blocks favor progressive disclosure over vertical bloat, maximizing operational screen real estate.
- **Scannable Modular Cards:** Distinct content buckets utilize light structural fills and subtle dividers rather than heavy borders or multi-tier drop shadows.
- **Tactile Clarity:** Interactive controls provide precise micro-states and generous touch zones (minimum 44x44px hit targets) without visual clutter.

## Colors

The palette balances precise operational teal accents against an ultra-neutral canvas to ensure rapid scanning and error-free monetary workflows:

- **Primary (`#238D9D`):** Primary actions, critical active states, active tab indicators, and essential navigation landmarks.
- **Dark Teal / Interactive Dark (`#1E7E8D`):** Primary button hover/pressed states, key metrics emphasis, and success validation badges.
- **Light Teal / Tinted Canvas (`#EAF7F9`):** Selected table rows, active input tinting, primary badge fills, and contextual status containers.
- **Text & Neutral Layers:**
  - High-Emphasis Content: `#0D0E0C` (98% contrast against canvas, optimized for currency values and critical labels).
  - Secondary / Supporting Text: `#504C4C` (timestamps, secondary table headers, helper captions).
  - Base Canvas: `#FCFCFC`.
  - Surface Containers / Cards: `#F7F7F7`.
  - Dividers & Boundaries: `#E2E2E2`.
- **System States & Alerts:**
  - Destructive / Error: `#D32F2F` text and icons, paired with `#FFEBEE` container fills.
  - Warning / Attention: `#F57C00` text and icons, paired with `#FFF3E0` container fills.
  - Verification / Settlement: `#1E7E8D` / `#238D9D` anchored against `#EAF7F9`.

## Typography

DM Sans powers the entire hierarchy, offering low-contrast geometric stability that remains readable at fast glance speeds across transactional flows.

- **Numerics & Currencies:** Use tabular figures (`font-variant-numeric: tabular-nums`) across all metrics, ledger tables, currency inputs, and transaction records to prevent column drift.
- **Hierarchy Structure:**
  - `data-metric` is reserved strictly for monetary balances, daily gross volumes, and core transaction totals.
  - `headline-lg` and `headline-lg-mobile` anchor primary page headers; mobile variants drop from 32px to 26px to prevent title wrap on 360px viewports.
  - `label-sm` operates in uppercase for table header columns and transaction status pills with enhanced letter-spacing (0.04em).
  - Touch targets for any interactive typographic component (links, breadcrumbs, action pills) must preserve an invisible padding boundary of at least 44px on mobile devices.

## Layout & Spacing

The layout model is a flexible fluid grid designed for multi-tier point-of-sale displays, tablets, and desktop operation suites.

- **Breakpoints:**
  - Mobile: `< 640px` (4-column grid, 16px margins, 16px gutters).
  - Tablet / POS Display: `640px – 1024px` (8-column grid, 24px margins, 16px gutters).
  - Desktop Console: `> 1024px` (12-column grid, max-width 1440px centered, 32px margins, 24px gutters).
- **Mobile Header Compaction:** Mobile screens feature condensed inline title bars (height: 56px) with an integrated progressive-disclosure trigger (overflow sheet or accordion drawer) for filter tools, date pickers, and merchant account pickers.
- **Rhythm & Structure:**
  - Component interior padding scales from `space-sm` (compact list items, inline chips) to `space-lg` (standard cards) and `space-xl` (expanded modal dialogs).
  - Structural separation between cards and data tables relies strictly on `space-md` to `space-xl`, ensuring high density without suffocating data visualization.

## Elevation & Depth

Visual hierarchy prioritizes surface tone distinctions over heavy shadows. This avoids visual noise and keeps the focus purely on merchant transactions.

- **Surface Tiers:**
  - **Base Canvas (Level 0):** `#FCFCFC` holds background page frames.
  - **Container Cards (Level 1):** `#F7F7F7` paired with a 1px border of `#E2E2E2`. Relies on low-contrast structural boundaries rather than drop shadows.
  - **Floating Tooltips & Popovers (Level 2):** Elevated via an ultra-subtle ambient shadow: `box-shadow: 0 2px 8px rgba(13, 14, 12, 0.04), 0 1px 2px rgba(13, 14, 12, 0.02)` bordered by `#E2E2E2`.
  - **Modals & Slide-out Drawers (Level 3):** Grounded by a solid `#FCFCFC` or `#FFFFFF` fill, bordered with `#E2E2E2`, elevated with `box-shadow: 0 12px 32px rgba(13, 14, 12, 0.08), 0 2px 6px rgba(13, 14, 12, 0.04)`. Background scrim uses `rgba(13, 14, 12, 0.4)` with light backdrop blur (`4px`).
- **Focus Rings & Interactive Outlines:**
  - Focus state: A dual-boundary ring using a 2px offset in `#FCFCFC` followed by a 2px solid ring in `#238D9D`.

## Shapes

The interface employs a disciplined rounded corner scale (`roundedness: 2`) to balance contemporary software appeal with industrial efficiency.

- **Standard Elements (8px / `rounded-md`):** Form input fields, buttons, interactive table row hover containers, and dropdown lists.
- **Cards & Data Modules (12px to 16px / `rounded-lg` to `rounded-xl`):** Primary merchant dashboard cards, analytics modules, and transaction groups use 12px (`0.75rem`), moving to 16px (`1rem`) on desktop containers.
- **Pills / Full Radius (`rounded-full`):** Reserved exclusively for status indicators (Paid, Pending, Failed, Refunded), quick-filter pills, and avatar/merchant badges.

## Components

### Buttons
- **Primary:** Filled `#238D9D` with white text (`#FCFCFC`). Hover state: `#1E7E8D`. Height: 44px (touch target compliant). Border-radius: 8px. Typography: `label-lg`.
- **Secondary / Outline:** Background transparent, border: 1px solid `#E2E2E2`, text `#0D0E0C`. Hover state: background `#F7F7F7` with border `#238D9D`.
- **Tertiary / Ghost:** Borderless, background transparent, text `#1E7E8D`. Hover state: `#EAF7F9` background.
- **Destructive:** Background `#FFEBEE`, border: 1px solid `#FFCDD2`, text `#D32F2F`. Hover state: background `#D32F2F` with white text.

### Chips & Status Badges
- **Status Indicator Pill:** Height: 24px. Padding: 0 10px. Rounded-full. Typography: `label-sm`.
  - *Success / Verified:* Background `#EAF7F9`, text `#1E7E8D`, dot `#238D9D`.
  - *Pending / Warning:* Background `#FFF3E0`, text `#F57C00`.
  - *Critical / Failed:* Background `#FFEBEE`, text `#D32F2F`.
- **Filter Chips:** Height: 32px. Border: 1px solid `#E2E2E2`, background `#FCFCFC`. Active state: background `#EAF7F9`, border `#238D9D`, text `#1E7E8D`.

### Cards & Modular Containers
- **Dashboard Metric Card:** Background `#F7F7F7`, border: 1px solid `#E2E2E2`, border-radius: 12px, padding: 16px. Internal hierarchy: `label-md` for subtitle/metric name, `data-metric` for primary monetary value, followed by comparative trend badges. No cover imagery or card header illustrations.

### Input Fields & Controls
- **Text Inputs:** Height: 44px. Background `#FCFCFC`, border: 1px solid `#E2E2E2`, border-radius: 8px, text `#0D0E0C`. Focus: border 1.5px solid `#238D9D`, subtle light teal wash (`background: #FCFCFC; box-shadow: 0 0 0 3px rgba(35, 141, 157, 0.12)`).
- **Currency Entry:** Inputs include a static `#504C4C` currency symbol prefix and large, monospaced tabular numerals (`title-md` or `headline-sm`).
- **Checkboxes & Radios:** 20x20px dimension. Inactive: border 1.5px solid `#E2E2E2`, background `#FCFCFC`. Checked: background `#238D9D`, border `#238D9D` with white checkmark icon.

### Lists & Data Tables
- **Table Structure:** Header row height 40px, text uppercase `label-sm` in `#504C4C`, border-bottom 1px solid `#E2E2E2`. Body row height: 52px. Hover row: `#EAF7F9` (30% opacity) or `#F7F7F7`. Dividers: 1px solid `#E2E2E2`.
- **Compact Mobile Ledger:** Swaps multi-column table to single 2-line list item: left side displays merchant/customer name and timestamp; right side displays numeric amount with aligned status chip beneath.